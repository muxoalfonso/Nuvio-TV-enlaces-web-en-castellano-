const peliplus = require("./peliplus");
const estrenoscinesaa = require("./estrenoscinesaa");

async function searchAll(query) {
  const settled = await Promise.allSettled([
    peliplus.search(query),
    estrenoscinesaa.search(query)
  ]);

  const combined = [];
  for (const result of settled) {
    if (result.status === "fulfilled") combined.push(...result.value);
    else console.warn("[mi-nuvio-js-plugin]", result.reason?.message || result.reason);
  }

  const seen = new Set();
  return combined.filter(item => {
    const key = item.title.toLocaleLowerCase("es")
      .normalize("NFD").replace(/\p{Diacritic}/gu, "");
    if (seen.has(key)) return false;
    seen.add(key);
    return true;
  });
}

module.exports = { searchAll, sources: [peliplus, estrenoscinesaa] };

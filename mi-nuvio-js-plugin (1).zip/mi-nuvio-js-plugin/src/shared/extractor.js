function decodeEntities(s) {
  return String(s || "")
    .replace(/&amp;/gi, "&")
    .replace(/&quot;/gi, '"')
    .replace(/&#39;/gi, "'")
    .replace(/&#x([0-9a-f]+);/gi, (_, h) => String.fromCodePoint(parseInt(h, 16)))
    .replace(/&#(\d+);/g, (_, n) => String.fromCodePoint(Number(n)));
}

function absoluteUrl(value, baseUrl) {
  if (!value) return null;
  try {
    const url = new URL(decodeEntities(value.trim()), baseUrl);
    if (!["http:", "https:"].includes(url.protocol)) return null;
    return url.href;
  } catch {
    return null;
  }
}

// Extracts page-level catalog cards and their original page URLs only.
// It intentionally does not inspect players or extract media/stream URLs.
function extractPageCards(html, pageUrl, source) {
  const results = [];
  const seen = new Set();
  const anchors = String(html || "").match(/<a\b[^>]*>[\s\S]*?<\/a>/gi) || [];

  for (const anchor of anchors) {
    const hrefMatch = anchor.match(/\bhref\s*=\s*["']([^"']+)["']/i);
    if (!hrefMatch) continue;
    const href = absoluteUrl(hrefMatch[1], pageUrl);
    if (!href || new URL(href).origin !== new URL(source.baseUrl).origin) continue;

    const path = new URL(href).pathname;
    if (path === "/" || /\/(inicio|category|tag|genre|page|feed)(\/|$)/i.test(path)) continue;
    if (seen.has(href)) continue;

    const imgMatch = anchor.match(/<img\b[^>]*(?:alt|title)\s*=\s*["']([^"']+)["'][^>]*>/i);
    const titleMatch = anchor.match(/\btitle\s*=\s*["']([^"']+)["']/i);
    const text = anchor.replace(/<script[\s\S]*?<\/script>/gi, "")
      .replace(/<style[\s\S]*?<\/style>/gi, "")
      .replace(/<[^>]+>/g, " ")
      .replace(/\s+/g, " ").trim();

    const title = decodeEntities(titleMatch?.[1] || imgMatch?.[1] || text);
    if (!title || title.length < 2 || title.length > 160) continue;

    const posterMatch = anchor.match(/<img\b[^>]*(?:data-src|data-lazy-src|src)\s*=\s*["']([^"']+)["']/i);
    const poster = posterMatch ? absoluteUrl(posterMatch[1], pageUrl) : null;
    seen.add(href);
    results.push({
      source: source.id,
      sourceName: source.name,
      title,
      pageUrl: href,
      poster
    });
    if (results.length >= 40) break;
  }

  return results;
}

module.exports = { extractPageCards };

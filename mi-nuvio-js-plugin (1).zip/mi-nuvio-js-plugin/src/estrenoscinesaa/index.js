const { getText } = require("../shared/http");
const { extractPageCards } = require("../shared/extractor");

const source = {
  id: "estrenoscinesaa",
  name: "EstrenosCinesaa",
  baseUrl: "https://www.estrenoscinesaa.com",
  searchUrl: q => "https://www.estrenoscinesaa.com/?s=" + encodeURIComponent(q)
};

async function search(query) {
  if (!query || !String(query).trim()) return [];
  const page = await getText(source.searchUrl(String(query).trim()));
  return extractPageCards(page.text, page.url, source);
}

module.exports = { id: source.id, name: source.name, search };

const { getText } = require("../shared/http");
const { extractPageCards } = require("../shared/extractor");

const source = {
  id: "peliplus",
  name: "Peliplus",
  baseUrl: "https://pelisplus-to.com",
  searchUrl: q => "https://pelisplus-to.com/?s=" + encodeURIComponent(q)
};

async function search(query) {
  if (!query || !String(query).trim()) return [];
  const page = await getText(source.searchUrl(String(query).trim()));
  return extractPageCards(page.text, page.url, source);
}

module.exports = { id: source.id, name: source.name, search };

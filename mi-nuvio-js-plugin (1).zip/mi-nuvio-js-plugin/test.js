const { searchAll } = require("./src");
searchAll(process.argv.slice(2).join(" ") || "Batman")
  .then(results => console.log(JSON.stringify(results, null, 2)))
  .catch(error => { console.error(error); process.exit(1); });

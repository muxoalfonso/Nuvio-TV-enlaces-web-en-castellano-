const esbuild = require("esbuild");

Promise.all([
  esbuild.build({
    entryPoints: ["src/peliplus/index.js"],
    outfile: "dist/peliplus.js",
    bundle: true,
    platform: "browser",
    format: "cjs",
    target: ["es2020"]
  }),
  esbuild.build({
    entryPoints: ["src/estrenoscinesaa/index.js"],
    outfile: "dist/estrenoscinesaa.js",
    bundle: true,
    platform: "browser",
    format: "cjs",
    target: ["es2020"]
  })
]).then(() => console.log("Bundles creados en dist/"))
  .catch(error => { console.error(error); process.exit(1); });

# Mi Nuvio JavaScript Plugin

Plugin modular de ejemplo para dos fuentes públicas: Peliplus y EstrenosCinesaa.

## Contenido

- `manifest.json`: metadatos y registro de los dos scrapers.
- `src/peliplus/`: adaptador de búsqueda de Peliplus.
- `src/estrenoscinesaa/`: adaptador de búsqueda de EstrenosCinesaa.
- `src/shared/http.js`: solicitudes HTTP.
- `src/shared/extractor.js`: extracción de títulos, portadas y enlaces a fichas.
- `src/index.js`: búsqueda combinada.
- `build.js`: genera los bundles.

## Instalar y probar

Requiere Node.js 20+.

```bash
npm install
npm run build
node test.js "Batman"
```

Los bundles se generan en `dist/`.

## Importante sobre compatibilidad

Este ZIP conserva la estructura modular solicitada y añade un manifiesto de ejemplo. El esquema exacto de `manifest.json`, el contrato de entrada/salida del scraper y la forma de empaquetado deben cotejarse con la versión de Nuvio donde se vaya a instalar; no se debe asumir que el manifiesto de ejemplo es instalable sin adaptación.

Las webs pueden cambiar su HTML, usar JavaScript o bloquear solicitudes automatizadas. Los selectores son heurísticos y requieren pruebas reales.

Este plugin solo busca fichas y devuelve URL de páginas originales. No inspecciona reproductores ni extrae enlaces de vídeo, no evade DRM, autenticación, CAPTCHA, paywalls ni controles de acceso. Utiliza las fuentes solo si tienes autorización y respetando sus condiciones.
